function ClockWidget(id){
	var root = document.getElementById(id);
	var h_hand = null;
	var m_hand = null;
	var s_hand = null;
	this.start = function(){}
	this.stop = function(){}
	this.stInterval = function() {}
	this.setTime = function() {}


	if(root != null){
		var hands = root.querySelectorAll('.clockHand label')
		var h_hand = hands[0];
		var m_hand = hands[1];
		var s_hand = hands[2];
		var timer = null;

		var counter = 1;
		var sec_counter = 0;
		var min_counter = 0;
		var sec_counter = 0;

		function startTimer() {
			sec_counter++;
			console.log(sec_counter);
			h_hand.innerHTML = sec_counter;
		}

		this.start = function() {
			console.log("start");
			var timer = setInterval(startTimer,1000);
		}
		this.stop = function() {
			console.log("stop");
		}
		this.stInterval = function() {
			console.log("set Interval");
		}
		this.setTime = function() {
			console.log("set time");
		}
	}
}